package geometries;
import primitives.*;

public interface Geometry {
	Vector getNormal(Point point);
}
