package tests;

import org.junit.Test;

import elements.AmbientLight;
import elements.Camera;
import geometries.*;
import primitives.*;
import renderer.ImageWriter;
import renderer.Render;
import scene.Scene;

public class RenderTest {
	@Test
	public void basicRendering(){
		Scene scene = new Scene("Test scene");
		scene.setCameraAndDistance(100, new Camera(Point.ZERO,  Vector.Z_AXIS, Vector.NEGATIVE_Y_AXIS));
		scene.setBackground(new Color(0, 0, 0));
		scene.setAmbientLight(new AmbientLight(new Color(100, 100, 100), 2));
		Geometries geometries = new Geometries();
		scene.setGeometries(geometries);
		geometries.add(new Sphere(50, new Point(0, 0, 150)));

		geometries.add(new Triangle(new Point( 100, 0, 149),
				 					new Point(  0, 100, 149),
				 					new Point( 100, 100, 149)));

		geometries.add(new Triangle(new Point( 100, 0, 149),
				 			 		new Point(  0, -100, 149),
				 			 		new Point( 100,-100, 149)));

		geometries.add(new Triangle(new Point(-100, 0, 149),
				 					new Point(  0, 100, 149),
				 					new Point(-100, 100, 149)));

		geometries.add(new Triangle(new Point(-100, 0, 149),
				 			 		new Point(  0,  -100, 149),
				 			 		new Point(-100, -100, 149)));

		ImageWriter imageWriter = new ImageWriter("test0", 500, 500, 500, 500);
		Render render = new Render(imageWriter, scene);

		render.renderImage();
		render.printGrid(50, new Color(255,255,255));
		render.writeToImage();
	}
}