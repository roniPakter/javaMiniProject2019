/*
 * Aharon Packter ID 201530508
 * Shlomo Perlov ID 206914301
 * 25/03/2019
 * 
 * Mini project in Software Engineering
 * Exercise 2
 */
package geometries;

import java.util.ArrayList;
import java.util.List;

import primitives.Point;
import primitives.Ray;
import primitives.Util;
import primitives.Vector;

/**
 * represents a plane in the space
 */
public class Plane implements Geometry {
	protected Point point;
	protected Vector normalVector;

	// ***************** Constructors ******************** //
	/**
	 * cotr with a point and a normal vector
	 * 
	 * @param pointParm
	 * @param normalParm
	 */
	public Plane(Point pointParm, Vector normalParm) {
		point = new Point(pointParm);
		normalVector = (new Vector(normalParm)).normalization();
	}

	/**
	 * Ctor with three points
	 * 
	 * @param point1
	 * @param point2
	 * @param point3
	 */
	public Plane(Point point1, Point point2, Point point3) {
		Vector a = point2.subtract(point1);
		Vector b = point3.subtract(point1);
		normalVector = a.crossProduct(b).normalization();
		point = new Point(point1);

	}

	// ***************** Getters ******************** //
	/**
	 *get a point that is in the plane
	 */
	public Point getPoint() {
		return point;
	}
	
	/**
	 * get a normalized vector that is orthogonal to the plane
	 */
	public Vector getNormal() {
		return normalVector;
	}

	// ***************** Administration ******************** //
	@Override
	public String toString() {
		return "Point: " + point + "\nNormal vector: " + normalVector;
	}

	// ***************** Operations ******************** //
	@Override
	public Vector getNormal(Point point) {
		return normalVector;
	}

	/**
	 * returns a list with all intersection points of a given ray with the plane
	 */
	@Override
	public List<Point> findIntersections(Ray ray) {
		List<Point> list;
		//in case the ray is included in the plane or parallel to it: empty list
		if (Util.isZero(normalVector.DotProduct(ray.getVector())))
			return EMPTY_LIST;
		//in case (rare...) the base point is the representing point of the plane: add it.
		if(point.equals(ray.getBasePoint())) {
			list = new ArrayList<Point>();
			list.add(ray.getBasePoint());
			return list;
		}
		
		//t is the coefficient of the 
		double t= point.subtract(ray.getBasePoint()).DotProduct(normalVector)
				/ normalVector.DotProduct(ray.getVector());
		if(t< 0)
			return EMPTY_LIST;
		if (Util.isZero(t)) {
			list  = new ArrayList<Point>();
			list.add(ray.getBasePoint());
			return list;
		}
			
		Point p = new Point(ray.getBasePoint().addVector(ray.getVector().scale(t)));
		list  = new ArrayList<Point>();
		list.add(p);
		return list;
	}
}
