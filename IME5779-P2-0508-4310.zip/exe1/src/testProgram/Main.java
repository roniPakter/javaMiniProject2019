/*
 * Aharon Packter ID 201530508
 * Shlomo Perlov ID 206914301
 * 25/03/2019
 * 
 * Mini project in Software Engineering
 * Exercise 2
 */
package testProgram;

public class Main {

	public static void main(String[] args) throws Exception {
		try {
		}
		
		catch(IllegalArgumentException e){
			System.out.println(e.getMessage());
		}
		

	}

}

